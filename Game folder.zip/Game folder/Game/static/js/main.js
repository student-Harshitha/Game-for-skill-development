function startGame() {
    window.location.href = "/game";
}

function goHome() {
    window.location.href = "/";
}