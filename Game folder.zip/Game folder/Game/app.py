from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

sentences = [
    "The quick brown fox jumps over the lazy dog.",
    "Practice makes perfect.",
    "Stay positive, work hard, make it happen.",
    "Learning never exhausts the mind.",
    "The only limit to our realization of tomorrow is our doubts of today."
]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/game')
def game():
    sentence = random.choice(sentences)
    return render_template('game.html', sentence=sentence)

@app.route('/result', methods=['GET', 'POST'])
def result():
    if request.method == 'POST':
        user_text = request.form['user_text']
        original_sentence = request.form['original_sentence']
        time_taken = float(request.form['time_taken'])
        words = len(original_sentence.split())
        wpm = words / (time_taken / 60)
        return render_template('result.html', wpm=wpm, original_sentence=original_sentence, user_text=user_text)
    else:
        return "Method Not Allowed", 405

if __name__ == '__main__':
    app.run(debug=True)